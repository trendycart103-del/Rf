# RF রিসিভার — Android (Kotlin + Jetpack Compose)

RTL-SDR এর মাধ্যমে লাইভ স্পেকট্রাম, ওয়াটারফল ও FM রেডিও অডিও। হার্ডওয়্যার ছাড়া সিমুলেটর মোডেও চলে।

## GitHub থেকে APK বানানো (৫ ধাপ)
1. GitHub এ নতুন repository খুলুন।
2. এই ফোল্ডারের **সব ফাইল** (`.github` ফোল্ডারসহ) push করুন।
   - ওয়েব আপলোডে `.github` ফোল্ডার বাদ গেলে: Add file → Create new file → নাম দিন `.github/workflows/build.yml` এবং ফাইলের লেখা পেস্ট করুন।
3. **Actions** ট্যাবে "Build APK" চলবে (push করলেই নিজে চলে; না চললে Run workflow চাপুন)।
4. ৩–৫ মিনিট পর সম্পূর্ণ হলে রান খুলে নিচে **Artifacts → rf-receiver-apk** ডাউনলোড করুন।
5. জিপ খুলে `app-debug.apk` ফোনে ইনস্টল করুন (Unknown sources অনুমতি দিন)।

## ব্যবহার
- সোর্স "সিমুলেটর" দিয়ে শুরু করলে নকল সিগন্যাল দেখা যাবে।
- আসল রিসিভ: OTG দিয়ে RTL-SDR লাগান → "RTL-SDR driver" অ্যাপ (Play Store) চালু করুন → এখানে সোর্স "RTL-SDR (rtl_tcp)", 127.0.0.1 : 1234।
- স্পেকট্রামে ট্যাপ করলে সেই ফ্রিকোয়েন্সিতে টিউন হয়।

## কাঠামো
- `Sources.kt` — IQ উৎস (Simulator, rtl_tcp)। নতুন হার্ডওয়্যার যোগ করতে `IqSource` ইমপ্লিমেন্ট করুন।
- `Receiver.kt` — রিসিভ লুপ, FFT, FM ডিমডুলেশন, অডিও
- `Dsp.kt` — FFT
- `Ui.kt` — স্ক্রিন ডিজাইন
