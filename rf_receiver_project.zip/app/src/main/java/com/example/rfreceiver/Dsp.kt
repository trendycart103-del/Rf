package com.example.rfreceiver

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** সাধারণ radix-2 FFT (in-place)। আকার অবশ্যই FFT_N হতে হবে। */
object Dsp {
    private val cosT = FloatArray(FFT_N / 2) { cos(2.0 * PI * it / FFT_N).toFloat() }
    private val sinT = FloatArray(FFT_N / 2) { (-sin(2.0 * PI * it / FFT_N)).toFloat() }

    fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val half = len / 2
            val step = n / len
            var i = 0
            while (i < n) {
                for (k in 0 until half) {
                    val wr = cosT[k * step]
                    val wi = sinT[k * step]
                    val a = i + k
                    val b = a + half
                    val tr = re[b] * wr - im[b] * wi
                    val ti = re[b] * wi + im[b] * wr
                    re[b] = re[a] - tr
                    im[b] = im[a] - ti
                    re[a] += tr
                    im[a] += ti
                }
                i += len
            }
            len = len shl 1
        }
    }
}
