package com.example.rfreceiver

import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

const val FS = 1_920_000          // স্যাম্পল রেট (Hz)
const val FFT_N = 1024
const val BINS = 256              // স্ক্রিনে দেখানো বিন
const val ROWS = 120              // ওয়াটারফলের সারি
const val MIN_DB = -100f
const val MAX_DB = -20f
const val MIN_HZ = 24_000_000L
const val MAX_HZ = 1_766_000_000L

class Receiver {
    var running by mutableStateOf(false)
    var status by mutableStateOf("প্রস্তুত")
    var centerHz by mutableLongStateOf(100_000_000L)
    var gainDb by mutableFloatStateOf(30f)
    var volume by mutableFloatStateOf(0.8f)
    var audioOn by mutableStateOf(true)
    var useSim by mutableStateOf(true)
    var host by mutableStateOf("127.0.0.1")
    var port by mutableStateOf("1234")
    var spectrum by mutableStateOf(FloatArray(BINS) { MIN_DB })
    var peakHz by mutableLongStateOf(0L)
    var peakDb by mutableFloatStateOf(MIN_DB)
    var frame by mutableIntStateOf(0)

    val wfBitmap: Bitmap = Bitmap.createBitmap(BINS, ROWS, Bitmap.Config.ARGB_8888)
    private val wfPixels = IntArray(BINS * ROWS) { 0xFF000000.toInt() }

    @Volatile private var stopFlag = false
    @Volatile private var worker: Thread? = null

    // DSP অবস্থা
    private val re = FloatArray(FFT_N)
    private val im = FloatArray(FFT_N)
    private val win = FloatArray(FFT_N) { (0.5 - 0.5 * cos(2.0 * PI * it / (FFT_N - 1))).toFloat() }
    private var pRe = 0f
    private var pIm = 0f
    private var deY = 0f

    fun tune(hz: Long) {
        centerHz = hz.coerceIn(MIN_HZ, MAX_HZ)
    }

    fun start() {
        if (worker != null) return
        stopFlag = false
        running = true
        status = "সংযোগ হচ্ছে…"
        val t = Thread { loop() }
        t.isDaemon = true
        worker = t
        t.start()
    }

    fun stop() {
        stopFlag = true
    }

    private fun loop() {
        val src: IqSource =
            if (useSim) SimSource() else RtlTcpSource(host.trim(), port.trim().toIntOrNull() ?: 1234)
        var track: AudioTrack? = null
        try {
            var curFreq = centerHz
            var curGain = (gainDb * 10).toInt()
            src.open(curFreq, curGain)
            status = if (useSim) "সিমুলেটর চলছে" else "রিসিভ হচ্ছে"
            val iq = FloatArray(src.chunk * 2)
            val smooth = FloatArray(BINS) { MIN_DB }
            val audioBuf = ShortArray(src.chunk / 40 + 8)
            if (!useSim) {
                track = makeTrack()
                track.play()
            }
            var lastUi = 0L
            while (!stopFlag) {
                val f = centerHz
                if (f != curFreq) { curFreq = f; src.setFrequency(f) }
                val g = (gainDb * 10).toInt()
                if (g != curGain) { curGain = g; src.setGain(g) }

                src.read(iq)

                if (track != null) {
                    val n = demod(iq, audioBuf)
                    if (audioOn) track.write(audioBuf, 0, n)
                }
                val now = System.nanoTime()
                if (now - lastUi > 50_000_000L) {
                    lastUi = now
                    updateSpectrum(iq, smooth, curFreq)
                }
            }
            status = "বন্ধ"
        } catch (e: Exception) {
            status = "ত্রুটি: " + (e.message ?: e.javaClass.simpleName)
        } finally {
            try { track?.stop(); track?.release() } catch (_: Exception) {}
            src.close()
            worker = null
            running = false
        }
    }

    private fun makeTrack(): AudioTrack {
        val min = AudioTrack.getMinBufferSize(
            48000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        return AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(48000)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(max(min * 4, 48000))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
    }

    /** ওয়াইডব্যান্ড FM ডিমডুলেশন: 1.92 MS/s → /8 → 240 kS/s → ডিসক্রিমিনেটর → /5 → 48 kHz */
    private fun demod(iq: FloatArray, out: ShortArray): Int {
        val nIn = iq.size / 2
        var o = 0
        var acc = 0f
        var cnt = 0
        var i = 0
        while (i + 8 <= nIn && o < out.size) {
            var sr = 0f
            var si = 0f
            for (k in 0 until 8) {
                sr += iq[2 * (i + k)]
                si += iq[2 * (i + k) + 1]
            }
            sr /= 8f
            si /= 8f
            val x = sr * pRe + si * pIm
            val y = si * pRe - sr * pIm
            acc += atan2(y, x)
            pRe = sr
            pIm = si
            cnt++
            if (cnt == 5) {
                val d = acc / 5f
                acc = 0f
                cnt = 0
                deY += 0.294f * (d - deY)      // 50µs de-emphasis
                val v = (deY * 0.5f * volume * 32767f).coerceIn(-32768f, 32767f)
                out[o++] = v.toInt().toShort()
            }
            i += 8
        }
        return o
    }

    private fun updateSpectrum(iq: FloatArray, smooth: FloatArray, center: Long) {
        for (i in 0 until FFT_N) {
            re[i] = iq[2 * i] * win[i]
            im[i] = iq[2 * i + 1] * win[i]
        }
        Dsp.fft(re, im)
        val per = FFT_N / BINS
        val out = FloatArray(BINS)
        var pk = -1000f
        var pkBin = 0
        for (b in 0 until BINS) {
            var m = -1000f
            for (k in 0 until per) {
                val idx = (b * per + k + FFT_N / 2) % FFT_N
                val mag = sqrt(re[idx] * re[idx] + im[idx] * im[idx]) / FFT_N
                val db = 20f * log10(mag + 1e-9f)
                if (db > m) m = db
            }
            smooth[b] = 0.6f * smooth[b] + 0.4f * m
            out[b] = smooth[b]
            if (out[b] > pk) { pk = out[b]; pkBin = b }
        }
        // ওয়াটারফল
        System.arraycopy(wfPixels, 0, wfPixels, BINS, BINS * (ROWS - 1))
        for (b in 0 until BINS) wfPixels[b] = colorFor(out[b])
        wfBitmap.setPixels(wfPixels, 0, BINS, 0, 0, BINS, ROWS)

        peakHz = center + (((pkBin + 0.5) / BINS - 0.5) * FS).toLong()
        peakDb = pk
        spectrum = out
        frame++
    }

    private fun colorFor(db: Float): Int {
        val t = ((db - MIN_DB) / (MAX_DB - MIN_DB)).coerceIn(0f, 1f)
        val r: Float
        val g: Float
        val b: Float
        if (t < 0.33f) {
            r = 0f; g = 0f; b = 0.2f + t / 0.33f * 0.8f
        } else if (t < 0.66f) {
            val u = (t - 0.33f) / 0.33f
            r = u; g = u; b = 1f - u
        } else {
            val u = (t - 0.66f) / 0.34f
            r = 1f; g = 1f - u; b = 0f
        }
        return (0xFF shl 24) or ((r * 255).toInt() shl 16) or ((g * 255).toInt() shl 8) or (b * 255).toInt()
    }
}
