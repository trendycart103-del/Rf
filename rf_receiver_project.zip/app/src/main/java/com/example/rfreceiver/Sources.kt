package com.example.rfreceiver

import java.io.DataInputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/** IQ ডেটার উৎস। read() আউটপুটে interleaved I,Q (-1..1) ভরে। */
interface IqSource {
    val chunk: Int
    fun open(centerHz: Long, gainTenthsDb: Int)
    fun read(out: FloatArray)
    fun setFrequency(hz: Long)
    fun setGain(tenthsDb: Int)
    fun close()
}

/** হার্ডওয়্যার ছাড়া টেস্টের জন্য নকল সিগন্যাল। */
class SimSource : IqSource {
    override val chunk = 2048
    private var center = 100_000_000L
    private var n = 0L
    private val rnd = Random()
    private val sigs = listOf(
        99_500_000L to 0.30, 100_300_000L to 0.20, 101_100_000L to 0.12,
        433_920_000L to 0.25, 868_000_000L to 0.20, 1_090_000_000L to 0.15
    )

    override fun open(centerHz: Long, gainTenthsDb: Int) { center = centerHz }
    override fun setFrequency(hz: Long) { center = hz }
    override fun setGain(tenthsDb: Int) {}
    override fun close() {}

    override fun read(out: FloatArray) {
        Thread.sleep(40)
        for (i in 0 until chunk) {
            out[2 * i] = (rnd.nextGaussian() * 0.01).toFloat()
            out[2 * i + 1] = (rnd.nextGaussian() * 0.01).toFloat()
        }
        for ((hz, amp) in sigs) {
            val off = (hz - center).toDouble()
            if (abs(off) > FS * 0.45) continue
            for (i in 0 until chunk) {
                val t = (n + i) / FS.toDouble()
                val ph = 2 * PI * off * t + 4.0 * sin(2 * PI * 440.0 * t)
                out[2 * i] += (amp * kotlin.math.cos(ph)).toFloat()
                out[2 * i + 1] += (amp * sin(ph)).toFloat()
            }
        }
        n += chunk
    }
}

/**
 * rtl_tcp প্রোটোকল: Android এ "RTL-SDR driver" অ্যাপ (USB OTG) অথবা PC/Raspberry Pi তে rtl_tcp।
 * হেডার ১২ বাইট ("RTL0" ...), তারপর unsigned 8-bit IQ স্ট্রিম।
 * কমান্ড = ১ বাইট কোড + ৪ বাইট big-endian মান।
 */
class RtlTcpSource(private val host: String, private val port: Int) : IqSource {
    override val chunk = 16000
    private var sock: Socket? = null
    private var input: DataInputStream? = null
    private var output: OutputStream? = null
    private val raw = ByteArray(chunk * 2)

    private fun cmd(code: Int, value: Int) {
        val b = byteArrayOf(
            code.toByte(),
            (value ushr 24).toByte(), (value ushr 16).toByte(),
            (value ushr 8).toByte(), value.toByte()
        )
        output?.write(b)
        output?.flush()
    }

    override fun open(centerHz: Long, gainTenthsDb: Int) {
        val s = Socket()
        s.connect(InetSocketAddress(host, port), 4000)
        s.soTimeout = 8000
        s.tcpNoDelay = true
        sock = s
        input = DataInputStream(s.getInputStream())
        output = s.getOutputStream()
        val header = ByteArray(12)
        input!!.readFully(header)
        if (String(header, 0, 4, Charsets.US_ASCII) != "RTL0") {
            throw IllegalStateException("rtl_tcp হেডার মেলেনি")
        }
        cmd(0x02, FS)                    // sample rate
        cmd(0x01, centerHz.toInt())      // frequency
        cmd(0x03, 1)                     // manual gain mode
        cmd(0x04, gainTenthsDb)          // gain (0.1 dB)
    }

    override fun setFrequency(hz: Long) = cmd(0x01, hz.toInt())
    override fun setGain(tenthsDb: Int) = cmd(0x04, tenthsDb)

    override fun read(out: FloatArray) {
        input!!.readFully(raw)
        for (i in raw.indices) {
            out[i] = ((raw[i].toInt() and 0xFF) - 127.5f) / 127.5f
        }
    }

    override fun close() {
        try { sock?.close() } catch (_: Exception) {}
    }
}
