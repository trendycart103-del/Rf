package com.example.rfreceiver

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Bg = Color(0xFF0B1220)
private val Panel = Color(0xFF121C2F)
private val Accent = Color(0xFF4FC3F7)
private val Muted = Color(0xFF8FA3BF)
private val Good = Color(0xFF3DDC97)

@Composable
fun RfTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color(0xFF00344A),
            background = Bg,
            onBackground = Color(0xFFE6EEF9),
            surface = Panel,
            onSurface = Color(0xFFE6EEF9),
            secondaryContainer = Color(0xFF1E3A56),
            onSecondaryContainer = Color(0xFFD6ECFF)
        ),
        content = content
    )
}

fun fmtMHz(hz: Long): String = String.format(Locale.US, "%.3f", hz / 1e6)

private val PRESETS = listOf(
    "FM 92.0" to 92_000_000L,
    "FM 100.0" to 100_000_000L,
    "FM 104.0" to 104_000_000L,
    "ISM 433.92" to 433_920_000L,
    "LoRa 868" to 868_000_000L,
    "Air 121.5" to 121_500_000L,
    "ADS-B 1090" to 1_090_000_000L
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RfApp(r: Receiver) {
    var showDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Bg,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("RF রিসিভার", fontWeight = FontWeight.SemiBold) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Bg,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        },
        bottomBar = {
            Surface(color = Panel) {
                Button(
                    onClick = { if (r.running) r.stop() else r.start() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                        .height(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (r.running) Color(0xFFE5484D) else Accent,
                        contentColor = if (r.running) Color.White else Color(0xFF00344A)
                    )
                ) {
                    Text(
                        if (r.running) "■  বন্ধ করুন" else "▶  শুরু করুন",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    ) { pad ->
        Column(
            modifier = Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            FrequencyCard(r) { showDialog = true }
            SpectrumCard(r)
            WaterfallCard(r)
            ControlsCard(r)
            HelpCard()
            Spacer(Modifier.height(4.dp))
        }
    }

    if (showDialog) {
        FreqDialog(r.centerHz) { hz ->
            showDialog = false
            if (hz != null) r.tune(hz)
        }
    }
}

@Composable
private fun PanelCard(content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) { content() }
}

@Composable
fun FrequencyCard(r: Receiver, onEdit: () -> Unit) {
    var step by remember { mutableLongStateOf(100_000L) }
    PanelCard {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                r.status,
                color = if (r.running) Good else Muted,
                fontSize = 13.sp
            )
            Text(
                fmtMHz(r.centerHz) + " MHz",
                fontSize = 40.sp,
                fontWeight = FontWeight.Bold,
                color = Accent,
                modifier = Modifier
                    .padding(vertical = 4.dp)
                    .clickable(onClick = onEdit)
            )
            Text("সংখ্যায় ট্যাপ করে ফ্রিকোয়েন্সি লিখুন", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilledTonalButton(
                    onClick = { r.tune(r.centerHz - step) },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                ) { Text("◀  − " + stepLabel(step)) }
                FilledTonalButton(
                    onClick = { r.tune(r.centerHz + step) },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                ) { Text("+ " + stepLabel(step) + "  ▶") }
            }
            Row(
                Modifier.padding(top = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(25_000L, 100_000L, 1_000_000L).forEach { s ->
                    FilterChip(
                        selected = step == s,
                        onClick = { step = s },
                        label = { Text("স্টেপ " + stepLabel(s)) }
                    )
                }
            }
            LazyRow(
                modifier = Modifier.padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(PRESETS) { p ->
                    AssistChip(onClick = { r.tune(p.second) }, label = { Text(p.first) })
                }
            }
        }
    }
}

private fun stepLabel(s: Long): String =
    if (s >= 1_000_000L) "${s / 1_000_000L} MHz" else "${s / 1000L} kHz"

@Composable
fun SpectrumCard(r: Receiver) {
    val spec = r.spectrum
    val center = r.centerHz
    PanelCard {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("স্পেকট্রাম", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                if (r.running) {
                    Text(
                        "পিক ${fmtMHz(r.peakHz)} MHz · ${r.peakDb.toInt()} dB",
                        color = Good,
                        fontSize = 12.sp
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Canvas(
                Modifier
                    .fillMaxWidth()
                    .height(170.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0A1424))
                    .pointerInput(center) {
                        detectTapGestures { off ->
                            val frac = off.x / size.width
                            r.tune(center + ((frac - 0.5f) * FS).toLong())
                        }
                    }
            ) {
                val w = size.width
                val h = size.height
                for (i in 1..3) {
                    val y = h * i / 4f
                    drawLine(Color(0x22FFFFFF), Offset(0f, y), Offset(w, y), 1f)
                }
                for (i in 1..3) {
                    val x = w * i / 4f
                    drawLine(Color(0x14FFFFFF), Offset(x, 0f), Offset(x, h), 1f)
                }
                val fill = Path()
                val line = Path()
                fill.moveTo(0f, h)
                for (i in spec.indices) {
                    val x = i * (w / (BINS - 1))
                    val t = ((spec[i] - MIN_DB) / (MAX_DB - MIN_DB)).coerceIn(0f, 1f)
                    val y = h * (1f - t)
                    fill.lineTo(x, y)
                    if (i == 0) line.moveTo(x, y) else line.lineTo(x, y)
                }
                fill.lineTo(w, h)
                fill.close()
                drawPath(
                    fill,
                    Brush.verticalGradient(listOf(Accent.copy(alpha = 0.55f), Accent.copy(alpha = 0.03f)))
                )
                drawPath(line, Accent, style = Stroke(width = 2f))
                drawLine(Color(0x88FF6B6B), Offset(w / 2f, 0f), Offset(w / 2f, h), 2f)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmtMHz(center - FS / 2), color = Muted, fontSize = 11.sp)
                Text(fmtMHz(center), color = Muted, fontSize = 11.sp)
                Text(fmtMHz(center + FS / 2), color = Muted, fontSize = 11.sp)
            }
            Text("টিপস: গ্রাফে ট্যাপ করলে সেই ফ্রিকোয়েন্সিতে টিউন হবে", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun WaterfallCard(r: Receiver) {
    PanelCard {
        Column(Modifier.padding(12.dp)) {
            Text("ওয়াটারফল", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Canvas(
                Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.Black)
            ) {
                val tick = r.frame
                if (tick == Int.MIN_VALUE) return@Canvas
                drawImage(
                    image = r.wfBitmap.asImageBitmap(),
                    srcOffset = IntOffset.Zero,
                    srcSize = IntSize(BINS, ROWS),
                    dstOffset = IntOffset.Zero,
                    dstSize = IntSize(size.width.toInt(), size.height.toInt()),
                    filterQuality = FilterQuality.Low
                )
            }
        }
    }
}

@Composable
fun ControlsCard(r: Receiver) {
    PanelCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("নিয়ন্ত্রণ", fontWeight = FontWeight.SemiBold)

            Text("গেইন: ${r.gainDb.toInt()} dB", color = Muted, fontSize = 13.sp)
            Slider(value = r.gainDb, onValueChange = { r.gainDb = it }, valueRange = 0f..50f)

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("FM অডিও")
                    Text(
                        if (r.useSim) "সিমুলেটরে অডিও নেই" else "ওয়াইডব্যান্ড FM (৮৮–১০৮ MHz)",
                        color = Muted,
                        fontSize = 11.sp
                    )
                }
                Switch(checked = r.audioOn, onCheckedChange = { r.audioOn = it })
            }
            Text("ভলিউম: ${(r.volume * 100).toInt()}%", color = Muted, fontSize = 13.sp)
            Slider(value = r.volume, onValueChange = { r.volume = it }, valueRange = 0f..1f)

            Text("সোর্স", color = Muted, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = r.useSim,
                    enabled = !r.running,
                    onClick = { r.useSim = true },
                    label = { Text("সিমুলেটর") }
                )
                FilterChip(
                    selected = !r.useSim,
                    enabled = !r.running,
                    onClick = { r.useSim = false },
                    label = { Text("RTL-SDR (rtl_tcp)") }
                )
            }
            if (!r.useSim) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = r.host,
                        onValueChange = { r.host = it },
                        label = { Text("হোস্ট") },
                        singleLine = true,
                        enabled = !r.running,
                        modifier = Modifier.weight(2f)
                    )
                    OutlinedTextField(
                        value = r.port,
                        onValueChange = { r.port = it.filter { c -> c.isDigit() } },
                        label = { Text("পোর্ট") },
                        singleLine = true,
                        enabled = !r.running,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
fun HelpCard() {
    PanelCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("কীভাবে আসল RF রিসিভ করবেন", fontWeight = FontWeight.SemiBold)
            Text(
                "১. RTL-SDR ডংগল ফোনে USB OTG দিয়ে লাগান।\n" +
                    "২. Play Store থেকে \"RTL-SDR driver\" অ্যাপ ইনস্টল করে চালু (Start) করুন।\n" +
                    "৩. এখানে সোর্স = RTL-SDR (rtl_tcp), হোস্ট 127.0.0.1, পোর্ট 1234 রেখে শুরু করুন।\n" +
                    "বিকল্প: PC/Raspberry Pi তে rtl_tcp চালিয়ে তার IP দিন।",
                color = Muted,
                fontSize = 13.sp
            )
            Text(
                "দ্রষ্টব্য: RTL-SDR শুধু রিসিভ করতে পারে, তাই এই অ্যাপে সেন্ড/ট্রান্সমিট নেই।",
                color = Muted,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
fun FreqDialog(initial: Long, onDone: (Long?) -> Unit) {
    var text by remember { mutableStateOf(fmtMHz(initial)) }
    AlertDialog(
        onDismissRequest = { onDone(null) },
        title = { Text("ফ্রিকোয়েন্সি (MHz)") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
            )
        },
        confirmButton = {
            TextButton(onClick = {
                onDone(text.replace(',', '.').toDoubleOrNull()?.let { (it * 1e6).toLong() })
            }) { Text("ঠিক আছে") }
        },
        dismissButton = { TextButton(onClick = { onDone(null) }) { Text("বাতিল") } }
    )
}
